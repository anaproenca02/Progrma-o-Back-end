"use strict";

const form = document.getElementById("form");
const alerta = document.getElementById("alerta");
const btnSalvar = document.getElementById("btn-salvar");
const previa = document.getElementById("previa");

const campoNome = document.getElementById("nome");
const campoCategoria = document.getElementById("id_categoria");
const campoPreco = document.getElementById("preco");
const campoEstoque = document.getElementById("estoque");
const campoDescricao = document.getElementById("descricao");
const campoImagem = document.getElementById("imagem");

// Vazio na criação; preenchido com o id do produto na edição
const id = parseInt(form.dataset.id) || 0;

const tiposImagem = ["image/jpeg", "image/png", "image/gif", "image/webp"];
const tamanhoMaximoImagem = 2 * 1024 * 1024;

function mostrarErro(mensagem) {
	alerta.textContent = mensagem;
	alerta.classList.remove("d-none");
	window.scrollTo({ top: 0, behavior: "smooth" });
}

function esconderErro() {
	alerta.classList.add("d-none");
}

async function lerResposta(resposta) {
	let corpo = null;
	try {
		corpo = await resposta.json();
	} catch (e) {
		// resposta sem JSON
	}

	if (!resposta.ok) {
		throw new Error(typeof corpo === "string" ? corpo : "Erro inesperado (" + resposta.status + ")");
	}

	return corpo;
}

// ----- Validação no frontend (espelha a validação do backend) -----

function marcar(campo, mensagem) {
	const feedback = campo.parentElement.querySelector(".invalid-feedback");
	if (mensagem) {
		campo.classList.add("is-invalid");
		feedback.textContent = mensagem;
	} else {
		campo.classList.remove("is-invalid");
		feedback.textContent = "";
	}
	return !mensagem;
}

function validar() {
	let valido = true;
	let primeiroInvalido = null;

	function checar(campo, mensagem) {
		if (!marcar(campo, mensagem)) {
			valido = false;
			if (!primeiroInvalido)
				primeiroInvalido = campo;
		}
	}

	const nome = campoNome.value.normalize().trim();
	checar(campoNome, (nome.length < 2 || nome.length > 100) ? "Informe o nome (de 2 a 100 caracteres)" : "");

	checar(campoCategoria, campoCategoria.value ? "" : "Selecione uma categoria");

	const preco = parseFloat(campoPreco.value.trim().replace(",", "."));
	checar(campoPreco, (isNaN(preco) || preco < 0 || preco > 99999999.99) ? "Informe um preço válido (ex.: 19,90)" : "");

	const estoqueTexto = campoEstoque.value.trim();
	const estoque = Number(estoqueTexto);
	checar(campoEstoque, (!estoqueTexto || !Number.isInteger(estoque) || estoque < 0 || estoque > 1000000) ? "Informe um estoque inteiro maior ou igual a zero" : "");

	checar(campoDescricao, campoDescricao.value.length > 500 ? "A descrição deve ter no máximo 500 caracteres" : "");

	let erroImagem = "";
	const arquivo = campoImagem.files[0];
	if (arquivo) {
		if (!tiposImagem.includes(arquivo.type))
			erroImagem = "A imagem deve ser JPG, PNG, GIF ou WEBP";
		else if (arquivo.size > tamanhoMaximoImagem)
			erroImagem = "A imagem deve ter no máximo 2 MB";
	}
	checar(campoImagem, erroImagem);

	if (primeiroInvalido)
		primeiroInvalido.focus();

	return valido;
}

// Remove a marcação de erro assim que o usuário volta a editar o campo
for (const campo of [campoNome, campoCategoria, campoPreco, campoEstoque, campoDescricao, campoImagem]) {
	campo.addEventListener("input", () => marcar(campo, ""));
	campo.addEventListener("change", () => marcar(campo, ""));
}

// ----- Pré-visualização da imagem -----

function exibirPrevia(url) {
	if (url) {
		previa.src = url;
		previa.classList.add("visivel");
	} else {
		previa.removeAttribute("src");
		previa.classList.remove("visivel");
	}
}

campoImagem.addEventListener("change", () => {
	const arquivo = campoImagem.files[0];
	exibirPrevia(arquivo && tiposImagem.includes(arquivo.type) ? URL.createObjectURL(arquivo) : null);
});

// ----- Carregamento inicial -----

// Preenche o <select> com as categorias vindas da API (segunda tabela do banco)
async function carregarCategorias() {
	const resposta = await fetch("/api/categoria/listar");
	const categorias = await lerResposta(resposta);

	for (const categoria of categorias) {
		const opcao = document.createElement("option");
		opcao.value = categoria.id;
		opcao.textContent = categoria.nome;
		campoCategoria.appendChild(opcao);
	}
}

async function carregarProduto() {
	const resposta = await fetch("/api/produto/obter?id=" + id);
	const produto = await lerResposta(resposta);

	campoNome.value = produto.nome;
	campoDescricao.value = produto.descricao || "";
	campoPreco.value = Number(produto.preco).toFixed(2).replace(".", ",");
	campoEstoque.value = produto.estoque;
	// As categorias já foram carregadas, então dá para selecionar a atual do produto
	campoCategoria.value = produto.id_categoria;

	if (produto.imagem)
		exibirPrevia("/public/uploads/" + encodeURIComponent(produto.imagem));
}

async function iniciar() {
	try {
		btnSalvar.disabled = true;

		await carregarCategorias();

		if (id)
			await carregarProduto();

		btnSalvar.disabled = false;
	} catch (e) {
		mostrarErro(e.message);
	}
}

// ----- Envio -----

form.addEventListener("submit", async (evento) => {
	evento.preventDefault();

	esconderErro();

	if (!validar())
		return;

	// FormData em vez de JSON, porque a imagem é enviada junto (multipart/form-data)
	const dados = new FormData();
	if (id)
		dados.append("id", id);
	dados.append("nome", campoNome.value);
	dados.append("descricao", campoDescricao.value);
	dados.append("preco", campoPreco.value);
	dados.append("estoque", campoEstoque.value);
	dados.append("id_categoria", campoCategoria.value);
	if (campoImagem.files[0])
		dados.append("imagem", campoImagem.files[0]);

	btnSalvar.disabled = true;

	try {
		const resposta = await fetch(id ? "/api/produto/editar" : "/api/produto/criar", {
			method: (id ? "PUT" : "POST"),
			body: dados
		});

		await lerResposta(resposta);

		window.location.href = "/produto";
	} catch (e) {
		mostrarErro(e.message);
		btnSalvar.disabled = false;
	}
});

iniciar();
