"use strict";

const corpo = document.getElementById("corpo");
const alerta = document.getElementById("alerta");

function mostrarErro(mensagem) {
	alerta.textContent = mensagem;
	alerta.classList.remove("d-none");
}

function esconderErro() {
	alerta.classList.add("d-none");
}

// Lê a resposta da API: em caso de erro (status 400), o corpo é uma string com a mensagem
async function lerResposta(resposta) {
	let corpoResposta = null;
	try {
		corpoResposta = await resposta.json();
	} catch (e) {
		// resposta sem JSON
	}

	if (!resposta.ok) {
		throw new Error(typeof corpoResposta === "string" ? corpoResposta : "Erro inesperado (" + resposta.status + ")");
	}

	return corpoResposta;
}

function criarCelula(conteudo, classe) {
	const td = document.createElement("td");
	if (classe)
		td.className = classe;
	if (conteudo instanceof Node)
		td.appendChild(conteudo);
	else
		td.textContent = conteudo;
	return td;
}

function criarImagem(produto) {
	if (!produto.imagem) {
		const vazio = document.createElement("span");
		vazio.className = "produto-sem-imagem";
		vazio.textContent = "sem imagem";
		return vazio;
	}

	const img = document.createElement("img");
	img.className = "produto-miniatura";
	img.src = "/public/uploads/" + encodeURIComponent(produto.imagem);
	img.alt = "Imagem de " + produto.nome;
	img.loading = "lazy";
	return img;
}

function criarAcoes(produto) {
	const div = document.createElement("div");
	div.className = "d-flex gap-1";

	const editar = document.createElement("a");
	editar.className = "btn btn-sm btn-outline-primary";
	editar.href = "/produto/editar?id=" + produto.id;
	editar.textContent = "Editar";

	const excluir = document.createElement("button");
	excluir.type = "button";
	excluir.className = "btn btn-sm btn-outline-danger";
	excluir.textContent = "Excluir";
	excluir.addEventListener("click", () => excluirProduto(produto));

	div.appendChild(editar);
	div.appendChild(excluir);
	return div;
}

function formatarPreco(valor) {
	return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function renderizar(lista) {
	corpo.innerHTML = "";

	if (!lista.length) {
		const tr = document.createElement("tr");
		const td = criarCelula("Nenhum produto cadastrado.", "text-center text-muted");
		td.colSpan = 7;
		tr.appendChild(td);
		corpo.appendChild(tr);
		return;
	}

	for (const produto of lista) {
		const tr = document.createElement("tr");

		// Sempre usar textContent (e não innerHTML) para exibir dados digitados pelo usuário
		tr.appendChild(criarCelula(criarImagem(produto)));
		tr.appendChild(criarCelula(produto.id));
		tr.appendChild(criarCelula(produto.nome));
		tr.appendChild(criarCelula(produto.categoria));
		tr.appendChild(criarCelula(formatarPreco(produto.preco), "text-end"));
		tr.appendChild(criarCelula(produto.estoque, "text-end"));
		tr.appendChild(criarCelula(criarAcoes(produto), "coluna-acoes"));

		corpo.appendChild(tr);
	}
}

async function carregar() {
	try {
		esconderErro();
		const resposta = await fetch("/api/produto/listar");
		renderizar(await lerResposta(resposta));
	} catch (e) {
		corpo.innerHTML = "";
		mostrarErro(e.message);
	}
}

async function excluirProduto(produto) {
	if (!confirm("Deseja realmente excluir o produto \"" + produto.nome + "\"?"))
		return;

	try {
		esconderErro();
		const resposta = await fetch("/api/produto/excluir?id=" + produto.id, { method: "DELETE" });
		await lerResposta(resposta);
		await carregar();
	} catch (e) {
		mostrarErro(e.message);
	}
}

carregar();
