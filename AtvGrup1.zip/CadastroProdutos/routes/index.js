const express = require("express");
const wrap = require("express-async-error-wrapper");

const router = express.Router();

// Rotas que apenas renderizam as views EJS
// (os dados são carregados pelo JavaScript da página, via /api/...)
router.get("/", wrap(async (req, res) => {
	res.render("index/index", { titulo: "Início" });
}));

router.get("/produto", wrap(async (req, res) => {
	res.render("produto/index", { titulo: "Produtos" });
}));

router.get("/produto/criar", wrap(async (req, res) => {
	res.render("produto/criar", { titulo: "Novo produto" });
}));

router.get("/produto/editar", wrap(async (req, res) => {
	const id = parseInt(req.query["id"]);

	if (!id) {
		res.status(400);
		res.render("erro", { mensagem: "Id inválido" });
		return;
	}

	res.render("produto/editar", { titulo: "Editar produto", id: id });
}));

module.exports = router;
