const express = require("express");
const wrap = require("express-async-error-wrapper");
const Produto = require("../../models/produto");
const { receberImagem, removerImagem } = require("../../middleware/upload");

const router = express.Router();

router.get("/listar", wrap(async (req, res) => {
	const resultado = await Produto.listar();

	res.json(resultado);
}));

router.get("/obter", wrap(async (req, res) => {
	const id = parseInt(req.query["id"]);

	const resultado = await Produto.obter(id);

	if (typeof resultado === "string") {
		res.status(400);
	}

	res.json(resultado);
}));

// Criar e editar recebem multipart/form-data (por causa da imagem).
// O middleware receberImagem preenche req.body com os campos de texto
// e req.file com o arquivo enviado (se houver)
router.post("/criar", receberImagem, wrap(async (req, res) => {
	const imagem = (req.file ? req.file.filename : null);

	const resultado = await Produto.criar(req.body, imagem);

	if (typeof resultado === "string") {
		// Se deu erro, a imagem que acabou de ser salva não será usada
		removerImagem(imagem);
		res.status(400);
	}

	res.json(resultado);
}));

router.put("/editar", receberImagem, wrap(async (req, res) => {
	const imagem = (req.file ? req.file.filename : null);

	const resultado = await Produto.editar(req.body, imagem);

	if (typeof resultado === "string") {
		res.status(400);
	}

	res.json(resultado);
}));

router.delete("/excluir", wrap(async (req, res) => {
	const id = parseInt(req.query["id"]);

	const resultado = await Produto.excluir(id);

	if (typeof resultado === "string") {
		res.status(400);
	}

	res.json(resultado);
}));

module.exports = router;
