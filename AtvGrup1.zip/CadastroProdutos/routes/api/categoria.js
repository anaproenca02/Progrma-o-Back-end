const express = require("express");
const wrap = require("express-async-error-wrapper");
const Categoria = require("../../models/categoria");

const router = express.Router();

// Rota extra: devolve as categorias (tabela auxiliar) para preencher o <select>
// das telas de criação e edição de produto
router.get("/listar", wrap(async (req, res) => {
	const resultado = await Categoria.listar();

	res.json(resultado);
}));

module.exports = router;
