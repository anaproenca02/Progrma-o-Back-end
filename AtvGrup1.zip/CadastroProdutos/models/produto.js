const Sql = require("../data/sql");
const { removerImagem } = require("../middleware/upload");

class Produto {
	static validar(produto, criacao) {
		if (!produto) {
			return "Dados inválidos";
		}

		if (!criacao) {
			produto.id = parseInt(produto.id);

			if (!produto.id) {
				return "Id inválido";
			}
		}

		produto.nome = (produto.nome || "").normalize().trim();
		if (produto.nome.length < 2 || produto.nome.length > 100) {
			return "Nome inválido (de 2 a 100 caracteres)";
		}

		// A descrição é opcional
		produto.descricao = (produto.descricao || "").normalize().trim();
		if (!produto.descricao) {
			produto.descricao = null;
		} else if (produto.descricao.length > 500) {
			return "Descrição inválida (máximo de 500 caracteres)";
		}

		// Aceita tanto 19.90 quanto 19,90
		const preco = parseFloat(((produto.preco || "") + "").trim().replace(",", "."));
		if (isNaN(preco) || preco < 0 || preco > 99999999.99) {
			return "Preço inválido";
		}
		produto.preco = Math.round(preco * 100) / 100;

		const estoqueTexto = ((produto.estoque === undefined || produto.estoque === null ? "" : produto.estoque) + "").trim();
		const estoque = Number(estoqueTexto);
		if (!estoqueTexto || !Number.isInteger(estoque) || estoque < 0 || estoque > 1000000) {
			return "Estoque inválido";
		}
		produto.estoque = estoque;

		produto.id_categoria = parseInt(produto.id_categoria);
		if (!produto.id_categoria) {
			return "Categoria inválida";
		}

		return null;
	}

	// "imagem" é o nome do arquivo já salvo em public/uploads pelo multer (ou null)
	static async criar(produto, imagem) {
		const erro = Produto.validar(produto, true);
		if (erro)
			return erro;

		produto.imagem = imagem || null;

		try {
			return await Sql.connect(async (sql) => {
				const categoria = await sql.scalar("SELECT id FROM categoria WHERE id = ?", [produto.id_categoria]);
				if (!categoria) {
					return "Categoria não encontrada";
				}

				try {
					await sql.query("INSERT INTO produto (nome, descricao, preco, estoque, id_categoria, imagem) VALUES (?, ?, ?, ?, ?, ?)", [produto.nome, produto.descricao, produto.preco, produto.estoque, produto.id_categoria, produto.imagem]);
				} catch (e) {
					if (e.code && e.code === "ER_DUP_ENTRY") {
						return `O produto ${produto.nome} já existe`;
					}
					throw e;
				}

				produto.id = await sql.scalar("SELECT last_insert_id()");

				return produto;
			});
		} catch (e) {
			removerImagem(imagem);
			throw e;
		}
	}

	// Se "imagem" for null, mantém a imagem atual do produto
	static async editar(produto, imagem) {
		const erro = Produto.validar(produto, false);
		if (erro)
			return erro;

		try {
			const resultado = await Sql.connect(async (sql) => {
				const categoria = await sql.scalar("SELECT id FROM categoria WHERE id = ?", [produto.id_categoria]);
				if (!categoria) {
					return "Categoria não encontrada";
				}

				const lista = await sql.query("SELECT imagem FROM produto WHERE id = ?", [produto.id]);
				if (!lista.length) {
					return "Produto não encontrado";
				}

				const imagemAntiga = lista[0].imagem;

				try {
					if (imagem) {
						await sql.query("UPDATE produto SET nome = ?, descricao = ?, preco = ?, estoque = ?, id_categoria = ?, imagem = ? WHERE id = ?", [produto.nome, produto.descricao, produto.preco, produto.estoque, produto.id_categoria, imagem, produto.id]);
					} else {
						await sql.query("UPDATE produto SET nome = ?, descricao = ?, preco = ?, estoque = ?, id_categoria = ? WHERE id = ?", [produto.nome, produto.descricao, produto.preco, produto.estoque, produto.id_categoria, produto.id]);
					}
				} catch (e) {
					if (e.code && e.code === "ER_DUP_ENTRY") {
						return `O produto ${produto.nome} já existe`;
					}
					throw e;
				}

				// Só apaga a imagem antiga depois que o UPDATE deu certo
				if (imagem && imagemAntiga) {
					removerImagem(imagemAntiga);
				}

				return null;
			});

			// Se houve erro (string), a nova imagem enviada não será usada
			if (resultado && imagem) {
				removerImagem(imagem);
			}

			return resultado;
		} catch (e) {
			removerImagem(imagem);
			throw e;
		}
	}

	static async obter(id) {
		if (!id) {
			return "Id inválido";
		}

		return await Sql.connect(async (sql) => {
			const lista = await sql.query("SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.id_categoria, c.nome categoria, p.imagem FROM produto p INNER JOIN categoria c ON c.id = p.id_categoria WHERE p.id = ?", [id]);

			if (!lista.length) {
				return "Produto não encontrado";
			}

			return lista[0];
		});
	}

	static async listar() {
		return await Sql.connect(async (sql) => {
			const lista = await sql.query("SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.id_categoria, c.nome categoria, p.imagem FROM produto p INNER JOIN categoria c ON c.id = p.id_categoria ORDER BY p.id ASC");

			return lista;
		});
	}

	static async excluir(id) {
		if (!id) {
			return "Id inválido";
		}

		return await Sql.connect(async (sql) => {
			const imagem = await sql.scalar("SELECT imagem FROM produto WHERE id = ?", [id]);

			await sql.query("DELETE FROM produto WHERE id = ?", [id]);

			if (!sql.affectedRows) {
				return "Produto não encontrado";
			}

			removerImagem(imagem);

			return null;
		});
	}
}

module.exports = Produto;
