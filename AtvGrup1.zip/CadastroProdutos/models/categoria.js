const Sql = require("../data/sql");

class Categoria {
	// Usado apenas para preencher o <select> nas telas de criação/edição
	static async listar() {
		return await Sql.connect(async (sql) => {
			const lista = await sql.query("SELECT id, nome FROM categoria ORDER BY nome ASC");

			return lista;
		});
	}
}

module.exports = Categoria;
