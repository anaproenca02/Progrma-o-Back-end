const path = require("path");
const crypto = require("crypto");
const fs = require("fs");
const multer = require("multer");

// Pasta onde as imagens ficam salvas (servida em /public/uploads/...)
const pastaUploads = path.join(__dirname, "..", "public", "uploads");

const extensoes = {
	"image/jpeg": ".jpg",
	"image/png": ".png",
	"image/gif": ".gif",
	"image/webp": ".webp"
};

const tamanhoMaximo = 2 * 1024 * 1024; // 2 MB

const upload = multer({
	storage: multer.diskStorage({
		destination: (req, file, cb) => {
			fs.mkdirSync(pastaUploads, { recursive: true });
			cb(null, pastaUploads);
		},
		// Nome aleatório, para evitar colisões e nomes maliciosos enviados pelo cliente
		filename: (req, file, cb) => {
			cb(null, crypto.randomBytes(16).toString("hex") + extensoes[file.mimetype]);
		}
	}),
	limits: { fileSize: tamanhoMaximo, files: 1 },
	fileFilter: (req, file, cb) => {
		if (!extensoes[file.mimetype]) {
			cb(new Error("A imagem deve ser JPG, PNG, GIF ou WEBP"));
			return;
		}
		cb(null, true);
	}
}).single("imagem");

// Middleware usado nas rotas de criar/editar. Em vez de deixar o erro do multer
// cair no tratador padrão (que renderiza uma view), devolve um JSON com status 400,
// igual ao restante da API.
function receberImagem(req, res, next) {
	upload(req, res, (erro) => {
		if (!erro) {
			next();
			return;
		}

		if (erro.code === "LIMIT_FILE_SIZE") {
			res.status(400).json("A imagem deve ter no máximo 2 MB");
		} else {
			res.status(400).json(erro.message || "Erro ao enviar a imagem");
		}
	});
}

// Apaga uma imagem da pasta de uploads (ignora se não existir)
function removerImagem(nomeArquivo) {
	if (!nomeArquivo)
		return;

	// path.basename impede que um valor estranho saia da pasta de uploads
	fs.unlink(path.join(pastaUploads, path.basename(nomeArquivo)), () => { });
}

module.exports = { receberImagem, removerImagem, pastaUploads };
