# Cadastro de Produtos

CRUD de **Produto** (Node.js + Express + EJS + MySQL), baseado no projeto CadastroPessoas.

## Como executar

1. Execute o arquivo `sql/script.sql` no MySQL (cria o banco `loja`, as tabelas `categoria` e `produto` e as categorias iniciais).
   - Se for executar pelo terminal, use `mysql -uroot -p --default-character-set=utf8mb4 < sql/script.sql` para os acentos ficarem corretos.
2. Ajuste, se necessário, usuário/senha no arquivo `.env`.
3. `npm install`
4. `npm start` e abra http://127.0.0.1:3000

## Entidade

`produto`: id, nome, descricao (opcional), preco, estoque, id_categoria (FK para `categoria`), imagem (nome do arquivo salvo em `public/uploads`).

## Rotas

Views (renderizam EJS): `GET /`, `GET /produto`, `GET /produto/criar`, `GET /produto/editar?id=`

API:

| Método | Rota | Descrição |
| --- | --- | --- |
| GET | `/api/produto/listar` | lista os produtos (com o nome da categoria) |
| GET | `/api/produto/obter?id=` | obtém um produto |
| POST | `/api/produto/criar` | cria (multipart/form-data, com `imagem` opcional) |
| PUT | `/api/produto/editar` | edita (multipart/form-data; sem `imagem` mantém a atual) |
| DELETE | `/api/produto/excluir?id=` | exclui (e apaga o arquivo da imagem) |
| GET | `/api/categoria/listar` | rota extra: valores do `<select>` de categoria |

## Estrutura

- `models/produto.js`: validação no backend + acesso ao banco
- `models/categoria.js`: leitura da tabela auxiliar
- `middleware/upload.js`: upload com multer (JPG/PNG/GIF/WEBP, até 2 MB, nome aleatório)
- `routes/index.js`: rotas das views; `routes/api/*.js`: rotas da API
- `views/produto/*.ejs` e `public/js/produto-*.js`: telas, validação no frontend e comunicação com a API
