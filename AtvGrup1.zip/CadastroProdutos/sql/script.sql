
-- Caso ocorra algum problema no login, executar o código abaixo, para arrumar a senha do usuário root:
-- ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';

CREATE DATABASE IF NOT EXISTS loja DEFAULT CHARACTER SET utf8mb4;

USE loja;

CREATE TABLE categoria (
  id int NOT NULL AUTO_INCREMENT,
  nome varchar(50) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY categoria_nome_UN (nome)
);

INSERT INTO categoria (nome) VALUES
  ('Eletrônicos'),
  ('Informática'),
  ('Livros'),
  ('Roupas'),
  ('Casa e Cozinha'),
  ('Esportes'),
  ('Brinquedos');

CREATE TABLE produto (
  id int NOT NULL AUTO_INCREMENT,
  nome varchar(100) NOT NULL,
  descricao varchar(500) NULL,
  preco decimal(10, 2) NOT NULL,
  estoque int NOT NULL DEFAULT 0,
  id_categoria int NOT NULL,
  imagem varchar(100) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY produto_nome_UN (nome),
  KEY produto_categoria_FK_IX (id_categoria),
  CONSTRAINT produto_categoria_FK FOREIGN KEY (id_categoria) REFERENCES categoria (id)
);
